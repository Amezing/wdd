package com.example.dagger.kotlin

import javax.inject.Qualifier

@Qualifier
annotation class ForApplication
