# Module dokka-maven-example

This is an example of how you can write module documentation with Dokka.

# Package demo

This package contains a few examples of Dokka usage.
